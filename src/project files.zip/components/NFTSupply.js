import React, { useEffect, useState } from "react";
import { getNFTContract } from "../utils/connect_ethers.js";

const NFTSupply = () => {
    const [totalSupply, setTotalSupply] = useState(null); //to store total supply of nfts
    useEffect(() => {
        const fetchSupply = async () => {
          try {
            const contract = getNFTContract();            
            let supply = 0;
            while (true) {
                try {
                    await contract.ownerOf(supply); // Check if token exists
                    supply++;
                } catch (error) {
                    break; // Exit loop when token doesn't exist
                }
            }

            setTotalSupply(supply.toString());
        } catch (error) {
            console.error("Error fetching total supply:", error); // Log any errors
          }
        };
        fetchSupply(); // to execute function
    }, []);
    return (
        <div>
      {/* Display the total number of NFTs minted or show 'Loading...' if the data hasn't loaded yet */}
      <h2>Total NFTs minted on the contract: {totalSupply !== null ? totalSupply : "Loading..."}</h2>
    </div>
    );
};
export default NFTSupply;