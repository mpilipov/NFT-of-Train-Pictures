import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import { getNFTContract } from "../utils/connect_ethers.js";

const UserNFTs = () => {
  const [walletAddress, setWalletAddress] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [userNFTs, setUserNFTs] = useState([]);
  const [nftCount, setNftCount] = useState(0);

  // Function to connect to the wallet
  const connectWallet = async () => {
    setUserNFTs([]);  // Clear NFTs on every wallet connect to indicate loading state
    if (window.ethereum) {
      try {
        await window.ethereum.request({ method: "eth_requestAccounts" });
        const provider = new ethers.BrowserProvider(window.ethereum);
        const signer = await provider.getSigner();
        const address = await signer.getAddress();
        setWalletAddress(address);

        const contract = getNFTContract().connect(signer);

        // Fetch total balance of NFTs owned by the user
        const balance = await contract.balanceOf(address);
        const ownedNFTs = [];

        // Define an upper bound for the number of tokens in the collection
        const maxSupply = 28;  // Adjust this value if your supply is larger

        // Iterate through the token IDs owned by the user
        for (let tokenId = 0; tokenId < maxSupply; tokenId++) {
          try {
            // Fetch the owner of the tokenId
            const owner = await contract.ownerOf(tokenId);

            // If the owner matches the connected wallet address, it's owned by the user
            if (owner.toLowerCase() === address.toLowerCase()) {
              const tokenURI = await contract.tokenURI(tokenId);
              ownedNFTs.push({
                tokenId: tokenId.toString(),
                owner: address,
                tokenURI: tokenURI,
                type: "minted", // or 'purchased' based on your logic
              });
            }
          } catch (error) {
            // This catches the error if the tokenId doesn't exist (e.g., ownerOf fails)
            console.log(`Token ${tokenId} does not exist or is not owned by the user.`);
          }
        }

        setUserNFTs(ownedNFTs);
        setNftCount(ownedNFTs.length);
        setErrorMessage("");
      } catch (error) {
        console.error("Wallet connection error:", error);
        setErrorMessage("An error occurred while connecting to the wallet.");
        setUserNFTs([]);  // Reset NFTs in case of error
      }
    } else {
      setErrorMessage("Metamask is not detected, you have to install it");
      setUserNFTs([]);  // Reset NFTs if no wallet is detected
    }
  };

  return (
    <div>
      <button onClick={connectWallet}>
        {"Connect Wallet"}
      </button>

      {/* Show "Loading..." text if userNFTs is empty */}
      {userNFTs.length === 0 && <p>Loading...</p>}

      {walletAddress && userNFTs.length > 0 && (
        <>
          <p><strong>Connected to:</strong> {walletAddress}</p>
          <p><strong>You own {nftCount} NFTs from this contract.</strong></p>

          <h3>Your NFTs</h3>

          {userNFTs.length === 0 ? (
            <p>You don't have any NFTs.</p>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "10px" }}>
              <thead>
                <tr style={{ backgroundColor: "#f2f2f2" }}>
                  <th style={{ padding: "8px", border: "1px solid #ddd" }}>Token ID</th>
                  <th style={{ padding: "8px", border: "1px solid #ddd" }}>Owner</th>
                  <th style={{ padding: "8px", border: "1px solid #ddd" }}>Token URI</th>
                  <th style={{ padding: "8px", border: "1px solid #ddd" }}>Type</th>
                </tr>
              </thead>
              <tbody>
                {userNFTs.map((nft) => (
                  <tr key={nft.tokenId}>
                    <td style={{ padding: "8px", border: "1px solid #ddd", textAlign: "center" }}>
                      {nft.tokenId}
                    </td>
                    <td style={{ padding: "8px", border: "1px solid #ddd" }}>
                      {nft.owner}
                    </td>
                    <td style={{ padding: "8px", border: "1px solid #ddd" }}>
                      <a href={nft.tokenURI} target="_blank" rel="noopener noreferrer">
                        View Metadata
                      </a>
                    </td>
                    <td style={{ padding: "8px", border: "1px solid #ddd", textAlign: "center" }}>
                      {nft.type === "minted" ? "Minted" : "Purchased"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </>
      )}

      {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}
    </div>
  );
};

export default UserNFTs;
