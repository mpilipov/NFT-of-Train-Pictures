import logo from './logo.svg';
import './App.css';
import React from "react";
import WalletConnect from "./components/WalletConnect.js";
import NFTSupply from "./components/NFTSupply.js";
import MintNFT from "./components/MintNFT.js";
import SellNFT from "./components/SellNFT.js";
import BuyNFT from "./components/BuyNFT.js";
import UserNFT from "./components/UserNFT.js";

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
        
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
      </header> */}
      <h1>Trains photos NFT dApp</h1>
      <WalletConnect />
      {/* <NFTSupply /> */}
      <UserNFT />
      <MintNFT />
      <SellNFT />
      <BuyNFT />
    </div>
  );
}

export default App;
