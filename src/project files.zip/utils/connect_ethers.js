import { ethers } from "ethers";
import { ContractABI } from "./contractABI.js";

const provider = new ethers.JsonRpcProvider(process.env.REACT_APP_INFURA_API_URL);
const contractAddress = process.env.REACT_APP_CONTRACT_ADDRESS;

const nftContract = new ethers.Contract(contractAddress, ContractABI, provider);

export const getNFTContract = () => nftContract;
//returns instance of nft smart contract






// export const listedNFTs = async () => {
//    const listedNFTs = await nftContract.getListedItems();
//    return listedNFTs.map(item => ({
//        tokenId: Number(item.tokenId),
//        price: ethers.formatEther(item.price)
//    }));
// };

// export const buyNFT = async (tokenId, price, signer) => {
//    const contractWithSigner = nftContract.connect(signer);
//    const tx = await contractWithSigner.buyItem(tokenId, { value: ethers.parseEther(price.toString()) });
//    await tx.wait();
//    return tx;
// };